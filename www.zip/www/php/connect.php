<?php

	//$db="new";
	$host="localhost";
	$pass="";
	$username="root";
	$database="newfarm";

	$connection=new mysqli($host,$username,$pass,$database);
	if (!$connection) {
		echo "Connection Failed".mysqli_error();
	}else{
		echo "Connection Successful";
	}

?>