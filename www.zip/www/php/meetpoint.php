<?php
	//connect to database
	$con=mysqli_connect("localhost","root","","newsfarm");
	if(!$con){
		echo "Could not connect to databse  ".mysql_error();
	}

	//mysqli fetch query
	$sql="SELECT * FROM products ORDER BY product_id DESC";
	$result=mysqli_query($con,$sql);//executing the query
	//fetch the data from table
	while ($row=mysqli_fetch_array($result)) {
		echo "<div id='product' border='2px blue'>";
			echo "<hr border='2px'>";
			echo "<span>";
			echo "<button id='edit'><img src='img/edit-black.png'>Edit Post";
			echo "</button>";
			echo "</span>";
			echo "                              ";
			echo "<span>";
			echo "<button id='delete' class='center'><img src='img/delete-black.png'>Delete Post";
			echo "</button>";
			echo "</span>";
			echo "<p>Product:".$row['product']."</p>";
			echo "<p>Location:".$row['location']."</p>";
			echo "<p>Amount:".$row['amount']."</p>";
			echo "<p>Units:".$row['units']."</p>";
			echo "<p>Description:".$row['description']."</p>";
			echo "<hr border='2px'>";
			//echo "<button class='btn btn-success form-control' id='mode' data-target='#myModal' data-toggle='modal' onclick='news()'>";
			//echo "Supply";
			//echo "</button>";
			echo "<div class='panel small text-right'";
				echo "<div id='majibu'>";
				echo "</div>";
			echo "<form method='post' name='commentform'>";

				echo "<label for='comment'";
				echo "Comment";
				echo "</label>";
				echo "<textarea name='textcomments' placeholder='Enter Your Bid Here...'  class='form-group' required='' />" ;
				echo "</textarea>";
				echo "<br />";
				echo "<input type='submit' class='btn btn-success center' value='Comment here' name='submit' id='newscomment' onclick='smallcomment()' />";
			echo "</form>";
			echo "</div>";
		echo "</div";
			echo "<hr border='2px'>";

}
		/*stream fetched data into an array location amnt uniuts desc
		$data=array();
			while ($row=mysqli_fetch_array($result)) {
				$row_data=array(
					'product'=>$row['product'],
					'location'=>$row['location'],
					'amount'=>$row['amount'],
					'units'=>$row['units'],
					'desc'=>$row['description']
					);
				array_push($data, $row_data);
			}
			echo json_encode($data);*/
?>