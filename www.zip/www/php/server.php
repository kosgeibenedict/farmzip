<?php
	$con=mysqli_connect("localhost","root","","newsfarm");
	

	
	//variables from the register form
		if(isset($_POST)){
		$fname=$_POST['fullname'];
		$user=$_POST['username'];
		$status=$_POST['status'];
		$county=$_POST['county'];
		$email=$_POST['email'];
		$pass=$_POST['password'];
	}		
	//insert data to the database
		
		
		$input=mysqli_query($con,"INSERT INTO mfarmregister VALUES(null,'$fname','$user','$status','$county','$email','$pass')");
			if($input){
				echo "Registered Successfully";
				
			}else{
				echo mysqli_error($con);
			}

		