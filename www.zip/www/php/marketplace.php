<?php
	$con=mysqli_connect("localhost","root","","newsfarm");

	//capture variables product, location, amount, units, description
	if (isset($_POST)) {
		$product=$_POST['product'];
		$location=$_POST['location'];
		$amount=$_POST['amount'];
		$units=$_POST['unit'];
		$desc=$_POST['desc'];


	//insert data to database

		$input=mysqli_query($con,"INSERT INTO products VALUES(null,'$product','$location','$amount','$units','$desc')");
		if($input){
				echo "Request Send Successfully!";
				
			}else{
				echo mysqli_error($con);
			}
	}
?>