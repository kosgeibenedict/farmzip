<?php
	

	//echo "Successful Connection";
	$con=mysqli_connect("localhost","root","","newsfarm");
	if(!$con){
		echo "Could not connect to databse  ".mysql_error();
	}else{
		//echo "connected";
	}

	//get the variable
		if (isset($_POST)) {
			$comment=$_REQUEST['textcomments'];
				echo "$comment";
		}else{
			echo "comment not found";
		}
			
		
		
		
	//Insert to the dtatbase
			/*
				$input="INSERT INTO comment VALUES(null,'$comment')";
				mysqli_query($con,$input);
	

	//Retrieve the data
	$sql="SELECT * FROM comment ORDER BY id DESC";
	$result=mysqli_query($con,$sql);//executing the query

	//fetch using while
	while ($row=mysqli_fetch_array($result)) {
		echo "<div class='panel-body'>";
		
		echo "<p>".$row['comment']."</p>";
		
		echo "</div>";
		echo "<hr>";*
	}*/
	
	
?>