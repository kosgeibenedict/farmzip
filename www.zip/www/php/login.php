<?php
	$con=mysqli_connect("localhost","root","","newsfarm");
	session_start();

	//if(isset($_POST['btnloginto'])){
		$email=stripslashes($_REQUEST['email']);//removes backslashes
		$pass=stripslashes($_REQUEST['password']);
		$email=mysqli_real_escape_string($con,$email);//removes special characters
		$pass=mysqli_real_escape_string($con,$pass);

		//to check if the user exists in the database
		$query="SELECT * FROM login WHERE email='$email' and password='$pass'";
		$result=mysqli_query($con,$query) or die(mysqli_error());

		$rows=mysqli_num_rows($result);
			if ($rows==1) {
				$_SESSION['username']=$email;
				echo "match founds";
				return true;
			}else{
				echo "Could not find the match";
				return false;
			}

	
	
?>